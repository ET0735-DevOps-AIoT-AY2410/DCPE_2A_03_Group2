from hal import hal_lcd as LCD 
from hal import hal_keypad as keypad
from threading import Thread
import time
import queue
import readkey as key
import rfid as rfid
from hal import hal_rfid_reader as rfid_reader
import csv
import time
import zbarlight
from picamera import PiCamera
from PIL import Image
import RPi as GPIO
import os
import picammers as pick
import glob

picam2 = pick.initialize_picam()

database = {}

card_pin = 1234

lcd = LCD.lcd()
shared_keypad_queue = queue.Queue()

# Load the database

total_price = 0

def home():
    lcd.lcd_display_string("                    ",1)
    lcd.lcd_display_string("                    ",2)
    lcd.lcd_display_string("1, Scan Ready",1)
    lcd.lcd_display_string("3. Pay",2)
    if key.ret_key() == 1:
        scan()

def scan():
    lcd.lcd_display_string("                    ",1)
    lcd.lcd_display_string("                    ",2)
    lcd.lcd_display_string("Please Wait...",1)
    barcode_data = 0
    fn = os.path.basename("barcode.jpg")
    lcd.lcd_display_string("                    ",1)
    lcd.lcd_display_string("                    ",2)
    lcd.lcd_display_string("Please Scan...",1)
    condition_met = False
    while not condition_met:
        pick.capture_image(picam2)
        barcode_data = pick.decode_barcode(fn)
        print("scan in progress...")
        if barcode_data != 0:
            print("success")
            files = glob.glob(os.path.join(fn, '*'))
            for file in files:
                try:
                    os.remove(file)
                    print(f"Deleted {file}")
                except Exception as e:
                    print(f"Error deleting file {file}: {e}")
                    
            search_column = 'product_ID'
            target_column = 'price'
            search_value = barcode_data
            
            with open('gr_database.csv', mode='r') as infile:
               reader = csv.reader(infile)
               for row in reader:
                        # Check if the condition is met
                    if row[search_column] == search_value:
                            # Retrieve the target value
                            target_value = row[target_column]
                            print(f"Price of {search_value}: {target_value}")
                            break
                    else:
                        print(f"{search_value} not found.")
            product = target_value
            cd.lcd_display_string("                    ",1)
            lcd.lcd_display_string("                    ",2)
            lcd.lcd_display_string(product,1)
            condition_met = True
    home()
        

def main():
    
    key.key_reader()
    reader = rfid_reader.init()

    while(True): 
        lcd.lcd_display_string("1. Scanner Start",1)
        lcd.lcd_display_string("2. Power Off",2)

        if key.ret_key() == 1:
            lcd.lcd_display_string("                    ",1)
            lcd.lcd_display_string("                    ",2)
            lcd.lcd_display_string("1, Scan Ready",1)
            lcd.lcd_display_string("3. Pay",2)
            if key.ret_key() == 1:
                scan()
                
            if key.ret_key() == 3: # to be replaced with PICAM
                lcd.lcd_display_string("                    ",1)
                lcd.lcd_display_string("                    ",2)
                lcd.lcd_display_string("1 - PAYWAVE",1)
                lcd.lcd_display_string("2 - ATMPIN",2)

                if key.ret_key() == 1:
                    lcd.lcd_display_string("                    ",1)
                    lcd.lcd_display_string("                    ",2)
                    lcd.lcd_display_string("Scan your card",1)
                    uid = rfid.rfid_reader(reader)
                    
                #input atm card code
                if key.ret_key() == 2:
                    lcd.lcd_display_string("                    ",1)
                    lcd.lcd_display_string("                    ",2)
                    lcd.lcd_display_string("Please Key in",1)
                    lcd.lcd_display_string("Your PIN",2)
                    if key.ATMPIN(card_pin) == True:
                        print("Success")
                        break
                        
        if key.ret_key() == 2:
            lcd.lcd_display_string("                    ",1)
            lcd.lcd_display_string("                    ",2)
            lcd.lcd_display_string("Powering Off",1)
            time.sleep(1)
            lcd.lcd_display_string("                    ",1)
            lcd.lcd_display_string("                    ",2)
            lcd.backlight(0)
        
            if key.ret_key() == 1:
                lcd.lcd_display_string("                    ",1)
                lcd.lcd_display_string("                    ",2)
                lcd.lcd_display_string("Starting...",1)
                time.sleep(1)
                lcd.lcd_display_string("                    ",1)
                lcd.lcd_display_string("                    ",2)
                lcd.backlight(1)
                main()

if __name__ == "__main__":
    main()